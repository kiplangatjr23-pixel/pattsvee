/* =========================================
PATTSVEE CATERING SERVICES
PREMIUM WEBSITE JAVASCRIPT
========================================= */

/* =========================================
STICKY NAVBAR EFFECT
========================================= */

const navbar = document.querySelector(".navbar");

window.addEventListener("scroll", () => {

  if(window.scrollY > 50){

    navbar.style.background = "rgba(31,31,31,0.95)";
    navbar.style.boxShadow = "0 8px 20px rgba(0,0,0,0.15)";
    navbar.style.padding = "15px 0";

  } else {

    navbar.style.background = "rgba(31,31,31,0.45)";
    navbar.style.boxShadow = "none";
    navbar.style.padding = "20px 0";

  }

});

/* =========================================
FADE-UP SCROLL ANIMATION
========================================= */

const fadeElements = document.querySelectorAll(".fade-up");

const appearOnScroll = new IntersectionObserver((entries) => {

  entries.forEach((entry) => {

    if(entry.isIntersecting){

      entry.target.classList.add("active");

    }

  });

}, {
  threshold: 0.2
});

fadeElements.forEach((element) => {

  appearOnScroll.observe(element);

});

/* =========================================
SMOOTH ACTIVE NAVIGATION LINK
========================================= */

const sections = document.querySelectorAll("section");
const navLinks = document.querySelectorAll(".nav-links a");

window.addEventListener("scroll", () => {

  let current = "";

  sections.forEach((section) => {

    const sectionTop = section.offsetTop;
    const sectionHeight = section.clientHeight;

    if(pageYOffset >= sectionTop - 200){

      current = section.getAttribute("id");

    }

  });

  navLinks.forEach((link) => {

    link.classList.remove("active");

    if(link.getAttribute("href").includes(current)){

      link.classList.add("active");

    }

  });

});

/* =========================================
CONTACT FORM VALIDATION
========================================= */

const form = document.querySelector("form");

form.addEventListener("submit", function(e){

  e.preventDefault();

  const inputs = form.querySelectorAll("input, textarea");

  let valid = true;

  inputs.forEach((input) => {

    if(input.value.trim() === ""){

      valid = false;

      input.style.border = "2px solid red";

    } else {

      input.style.border = "none";

    }

  });

  if(valid){

    alert("Thank you for contacting Pattsvee Catering Services! We will get back to you shortly.");

    form.reset();

  }

});

/* =========================================
BUTTON HOVER GLOW EFFECT
========================================= */

const buttons = document.querySelectorAll(".btn");

buttons.forEach((button) => {

  button.addEventListener("mouseenter", () => {

    button.style.boxShadow = "0 10px 25px rgba(212,164,55,0.35)";

  });

  button.addEventListener("mouseleave", () => {

    button.style.boxShadow = "none";

  });

});

/* =========================================
IMAGE HOVER EFFECT
========================================= */

const galleryImages = document.querySelectorAll(".gallery-grid img");

galleryImages.forEach((image) => {

  image.addEventListener("mouseenter", () => {

    image.style.filter = "brightness(1.05)";

  });

  image.addEventListener("mouseleave", () => {

    image.style.filter = "brightness(1)";

  });

});

/* =========================================
SCROLL TO TOP BUTTON (OPTIONAL)
========================================= */

const scrollButton = document.createElement("button");

scrollButton.innerHTML = "↑";

scrollButton.classList.add("scroll-top");

document.body.appendChild(scrollButton);

scrollButton.style.position = "fixed";
scrollButton.style.bottom = "100px";
scrollButton.style.right = "25px";
scrollButton.style.width = "50px";
scrollButton.style.height = "50px";
scrollButton.style.borderRadius = "50%";
scrollButton.style.border = "none";
scrollButton.style.background = "#D4A437";
scrollButton.style.color = "#1F1F1F";
scrollButton.style.fontSize = "20px";
scrollButton.style.cursor = "pointer";
scrollButton.style.display = "none";
scrollButton.style.zIndex = "999";
scrollButton.style.transition = "0.3s ease";

window.addEventListener("scroll", () => {

  if(window.scrollY > 400){

    scrollButton.style.display = "block";

  } else {

    scrollButton.style.display = "none";

  }

});

scrollButton.addEventListener("click", () => {

  window.scrollTo({
    top:0,
    behavior:"smooth"
  });

});

/* =========================================
PRELOADER EFFECT
========================================= */

window.addEventListener("load", () => {

  document.body.classList.add("loaded");

});

/* =========================================
CONSOLE BRANDING
========================================= */

console.log(`
=========================================
PATTSVEE CATERING SERVICES
Serving Migori with Taste & Excellence
=========================================
`);